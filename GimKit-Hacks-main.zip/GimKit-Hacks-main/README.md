<h1 align="center">GimKit Hack</h1>
<h3 align="center">One of the best GimKit hacks.</h3>
<h2 align="center">Discord Support Server: https://discord.gg/abqMVbDanB</h2>
<h2 align="center">Credits to <a href="https://github.com/hostedposted">@hostedposted</a> for helping me!</h3>

#### Made by rxzyx (rzx). This is purley for education purposes.
- 📫 Have a problem? **Just write an issue and I will do my best to respond.**

## How To Use:

- Simply open the file that sounds more interesting, click the "Raw" button, then copy the code and paste it into the chrome console when you're on gimkit.

## Features:
- Default Scripts:
    - <a href="https://github.com/rxzyx/GimKit-Hacks/blob/main/Default%20Scripts/Answer%20Bot.js">Answer Bot</a> - Make a bot automatically answer the question. (Broken)
    - <a href="https://github.com/rxzyx/GimKit-Hacks/blob/main/Default%20Scripts/Show%20Correct%20Answers.js">Show Correct Answers</a> - Hide wrong answers on the screen. (Broken)
    - <a href="https://github.com/rxzyx/GimKit-Hacks/blob/main/Default%20Scripts/Free%20Premium.js">Free Premium</a> - Get free pro/premium.
- Trust No-One:
    - <a href="https://github.com/rxzyx/GimKit-Hacks/blob/main/Trust%20No-One/Show%20Imposters.js">Show Imposters</a> - This program will alert who the imposters are.
- Classic:
    - <a href="https://github.com/rxzyx/GimKit-Hacks/blob/main/Classic/Get%20Cash.js">Get Cash</a> - This program will set your cash to anything you want [after refreshing and (re-)joining a game.]

#### I am not responsible for your actions with these cheats.

<h3 align="left">Made With JavaScript:</h3>
<p align="left"> <a href="https://developer.mozilla.org/en-US/docs/Web/JavaScript" target="_blank" rel="noreferrer"> <img src="https://raw.githubusercontent.com/devicons/devicon/master/icons/javascript/javascript-original.svg" alt="javascript" width="40" height="40"/> </a> </p>

#### Copyright &copy; 2022 rzx.
